
const mongoose = require('mongoose');

const callRecordSchema = new mongoose.Schema({
  callerNumber: String,
  receiverNumber: String,
  startTime: Date,
  endTime: Date,
  duration: Number,
});

module.exports = mongoose.model('CallRecord', callRecordSchema);


const express = require('express');
const router = express.Router();
const CallRecord = require('../models');

// ROUTES Defined.
router.get('/', async (req, res) => {
  
});

router.get('/:id', async (req, res) => {
  
});const app = express();

router.post('/', async (req, res) => {
  
});


const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();


app.use(bodyParser.json());


mongoose.connect('mongodb://localhost:27017/call_records_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));


const callRecordRoutes = require('./routes/callRecords');
app.use('/api/call-records', callRecordRoutes);


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

router.put('/:id', async (req, res) => {
  
});

router.delete('/:id', async (req, res) => {
  
});

module.exports = router;
