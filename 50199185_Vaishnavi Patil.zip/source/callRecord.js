
const express = require('express');
const router = express.Router();
const CallRecord = require('../models');


router.get('/', async (req, res) => {
  try {
    const callRecords = await CallRecord.find();
    res.json(callRecords);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
const app = express();

router.get('/:id', async (req, res) => {
  try {
    const callRecord = await CallRecord.findById(req.params.id);
    if (callRecord) {
      res.json(callRecord);
    } else {
      res.status(404).json({ message: 'Call record not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST create call record
router.post('/', async (req, res) => {
  const callRecord = new CallRecord(req.body);
  try {
    const newCallRecord = await callRecord.save();
    res.status(201).json(newCallRecord);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const updatedCallRecord = await CallRecord.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (updatedCallRecord) {
      res.json(updatedCallRecord);
    } else {
      res.status(404).json({ message: 'Call record not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const deletedCallRecord = await CallRecord.findByIdAndDelete(req.params.id);
    if (deletedCallRecord) {
      res.json({ message: 'Call record deleted' });
    } else {
      res.status(404).json({ message: 'Call record not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();


app.use(bodyParser.json());


mongoose.connect('mongodb://localhost:27017/call_records_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));


const callRecordRoutes = require('./routes/callRecords');
app.use('/api/call-records', callRecordRoutes);


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

module.exports = router;
